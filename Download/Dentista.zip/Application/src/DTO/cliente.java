package DTO;

public class cliente {
    int cliente_id;
    String cliente_nome;
    String cliente_cpf;
    String cliente_email;
    String cliente_numero;
    String cliente_rua;
    String cliente_bairro;
    String cliente_cidade;
    String cliente_estado;
    
    public int getCliente_id() {
        return cliente_id;
    }

    public void setCliente_id(int cliente_id) {
        this.cliente_id = cliente_id;
    }

    public String getCliente_nome() {
        return cliente_nome;
    }

    public void setCliente_nome(String cliente_nome) {
        this.cliente_nome = cliente_nome;
    }

    public String getCliente_cpf() {
        return cliente_cpf;
    }

    public void setCliente_cpf(String cliente_cpf) {
        this.cliente_cpf = cliente_cpf;
    }

    public String getCliente_email() {
        return cliente_email;
    }

    public void setCliente_email(String cliente_email) {
        this.cliente_email = cliente_email;
    }

    public String getCliente_numero() {
        return cliente_numero;
    }

    public void setCliente_numero(String cliente_numero) {
        this.cliente_numero = cliente_numero;
    }

    public String getCliente_rua() {
        return cliente_rua;
    }

    public void setCliente_rua(String cliente_rua) {
        this.cliente_rua = cliente_rua;
    }

    public String getCliente_bairro() {
        return cliente_bairro;
    }

    public void setCliente_bairro(String cliente_bairro) {
        this.cliente_bairro = cliente_bairro;
    }

    public String getCliente_cidade() {
        return cliente_cidade;
    }

    public void setCliente_cidade(String cliente_cidade) {
        this.cliente_cidade = cliente_cidade;
    }

    public String getCliente_estado() {
        return cliente_estado;
    }

    public void setCliente_estado(String cliente_estado) {
        this.cliente_estado = cliente_estado;
    }
}