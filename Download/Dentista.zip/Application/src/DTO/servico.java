package DTO;

public class servico {
    int servico_id;
    String servico_desc;
    String servico_duracao;
    Double servico_valor;

    public int getServico_id() {
        return servico_id;
    }

    public void setServico_id(int servico_id) {
        this.servico_id = servico_id;
    }

    public String getServico_desc() {
        return servico_desc;
    }

    public void setServico_desc(String servico_desc) {
        this.servico_desc = servico_desc;
    }

    public String getServico_duracao() {
        return servico_duracao;
    }

    public void setServico_duracao(String servico_duracao) {
        this.servico_duracao = servico_duracao;
    }

    public Double getServico_valor() {
        return servico_valor;
    }

    public void setServico_valor(Double servico_valor) {
        this.servico_valor = servico_valor;
    }
}
